//
//  ParseBridge.h
//  FishBalls
//
//  Created by Spencer Barron on 7/6/13.
//  Copyright (c) 2013 Spencer Barron. All rights reserved.
//

#import <BridgeKit/JavaObject.h>

@class ParseUser;

@interface ParseUser: JavaObject

+ (ParseUser*) currentUser; 
+ (void)logOut;
- (void)initUser;
@end
