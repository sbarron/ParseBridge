//
//  ParseFacebookUtils.m
//  FishBalls
//
//  Created by Spencer Barron on 7/7/13.
//  Copyright (c) 2013 Spencer Barron. All rights reserved.
//

#import "ParseFacebookUtils.h"
#import <BridgeKit/AndroidActivity.h>
#import <BridgeKit/JavaList.h>
#import "LogInCallBack.h"

@implementation ParseFacebookUtils

+ (void)initializeJava
{
    // Note: this must be called for any class that registers custom
    // java apis, without this call the inheritance may not work as expected
    [super initializeJava];
	//initialize(String appId)
	[ParseFacebookUtils registerStaticMethod:@"initialize"
								selector:@selector(initializeFacebook:)
							 returnValue:nil
							   arguments:[NSString className], NULL];
				
	[ParseFacebookUtils registerStaticMethod:@"isLinked"
									selector:@selector(isLinkedWithUser:)
								 returnValue:[JavaClass boolean]
								   arguments:[ParseUser className], NULL];
	
	[ParseFacebookUtils registerStaticMethod:@"login"
									selector:@selector(logInWithPermissions:)
								 returnValue:nil
								   arguments:[JavaList className], [AndroidActivity className],[LogInCallBack className], NULL];
				
	[ParseFacebookUtils registerCallback:@"bridgeCallback"
						 selector:@selector(logInWithPermissions)
					  returnValue:nil
						arguments:[JavaClass intPrimitive], [JavaClass doublePrimitive], nil];

				//+ (void)logInWithPermissions:(NSArray *)permissions block:(PFUserResultBlock)block
	/*
	 public static void logIn(Collection<String> permissions,
	 Activity activity,
	 LogInCallback callback)
	*/
				
				
				
	/*NOT USED
	 + (BOOL)handleOpenURL:(NSURL *)url;
	 //PFFacebookUtils handleOpenURL:url];
	 
	 //public static boolean isLinked(ParseUser user)
	 + (BOOL)isLinkedWithUser:(PFUser *)user;
	 //[PFFacebookUtils isLinkedWithUser:[PFUser currentUser]])
	 
	 + (void)logInWithPermissions:(NSArray *)permissions block:(PFUserResultBlock)block;
	 
	 + (void)logInWithPermissions:(NSArray *)permissions block:(PFUserResultBlock)block
	 Parameters
	 permissions
	 The permissions required for Facebook log in. This passed to the authorize method on
	 the Facebook instance.
	 
	 block
	 The block to execute. The block should have the following argument signature:
	 (PFUser user, NSError error)*/
	//[PFFacebookUtils logInWithPermissions:permissionsArray block:^(PFUser *user, NSError *error)
	
	 NSLog(@"ParseFacebookUtils.h associated with %@", [[ParseFacebookUtils javaClass] className]);	
	
}

+ (NSString *)className
{
    return @"com.parse.ParseFacebookUtils";
}


@end
