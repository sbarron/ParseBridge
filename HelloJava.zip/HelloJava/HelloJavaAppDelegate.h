//
//  HelloJavaAppDelegate.h
//  HelloJava
//
//  Created by Collin Jackson on 5/27/13.
//  Copyright (c) 2013 Apportable. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloJavaAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
