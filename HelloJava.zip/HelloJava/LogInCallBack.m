//
//  ParseBridge.m
//  FishBalls
//
//  Created by Spencer Barron on 7/6/13.
//  Copyright (c) 2013 Spencer Barron. All rights reserved.
//

#import "LogInCallBack.h"
#import "ParseUser.h"
#import "ParseException.h"

@implementation LogInCallBack

// Any objc properties that are declared should declare dynamic,
// else automatic property sythesis will override the bridge registrations
 

+ (void)initializeJava
{
    // Note: this must be called for any class that registers custom
    // java apis, without this call the inheritance may not work as expected
    [super initializeJava];

		[LogInCallBack registerConstructorWithSelector:@selector(initLoginCallBack)
                                       arguments:nil];
	
		//-(void)done:(ParseUser*)user,(ParseException*)error;
		    [LogInCallBack registerInstanceMethod:@"done"
                               selector:@selector(done:)
							  arguments:[ParseUser className], [ParseException className], nil];
	
}

+ (NSString *)className
{
    return @"com.parse.LogInCallback";
}



@end
