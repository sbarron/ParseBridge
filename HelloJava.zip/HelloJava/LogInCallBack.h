//
//  LogInCallBack.h
//  FishBalls
//
//  Created by Spencer Barron on 7/8/13.
//  Copyright (c) 2013 Spencer Barron. All rights reserved.
//

#import <BridgeKit/JavaObject.h>
@class ParseUser;
@class ParseException;

@interface LogInCallBack: JavaObject

-(void) initLoginCallBack;
-(void)done :(ParseUser*)user :(ParseException*)error;

@end
