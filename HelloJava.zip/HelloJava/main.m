//
//  main.m
//  HelloJava
//
//  Created by Collin Jackson on 5/27/13.
//  Copyright (c) 2013 Apportable. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HelloJavaAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([HelloJavaAppDelegate class]));
  }
}
