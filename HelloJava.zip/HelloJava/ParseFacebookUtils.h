//
//  ParseFacebookUtils.h
//  FishBalls
//
//  Created by Spencer Barron on 7/7/13.
//  Copyright (c) 2013 Spencer Barron. All rights reserved.
//

#import <BridgeKit/JavaObject.h>

@class ParseUser;

@interface ParseFacebookUtils : JavaObject

+ (void)initializeFacebook:(NSString*)appId;
//+ (BOOL)handleOpenURL:(NSURL *)url;
//PFFacebookUtils handleOpenURL:url];

+ (BOOL)isLinkedWithUser:(ParseUser*)user;
//[PFFacebookUtils isLinkedWithUser:[PFUser currentUser]])

+ (void)logInWithPermissions:(NSArray *)permissions;// block:(PFUserResultBlock)block;
/*
+ (void)logInWithPermissions:(NSArray *)permissions block:(PFUserResultBlock)block
Parameters
permissions
The permissions required for Facebook log in. This passed to the authorize method on
the Facebook instance.

block
The block to execute. The block should have the following argument signature:
(PFUser user, NSError error)*/
//[PFFacebookUtils logInWithPermissions:permissionsArray block:^(PFUser *user, NSError *error)
@end
